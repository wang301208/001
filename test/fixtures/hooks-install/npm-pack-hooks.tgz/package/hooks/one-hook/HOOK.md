---
name: one-hook
description: One hook
metadata: {"assistant":{"events":["command:new"]}}
---

# One Hook