---
name: zip-hook
description: Zip hook
metadata: {"assistant":{"events":["command:new"]}}
---

# Zip Hook