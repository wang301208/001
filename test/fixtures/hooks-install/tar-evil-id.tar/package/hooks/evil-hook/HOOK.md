---
name: evil-hook
description: evil-hook
metadata: {"assistant":{"events":["command:new"]}}
---

# Hook