---
name: reserved-hook
description: reserved-hook
metadata: {"assistant":{"events":["command:new"]}}
---

# Hook