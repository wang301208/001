---
name: tar-hook
description: tar-hook
metadata: {"assistant":{"events":["command:new"]}}
---

# Hook